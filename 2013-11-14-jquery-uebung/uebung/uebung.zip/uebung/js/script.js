$( function() {

	/**
	 * Klick auf linken Pfeil.
	 *  - Prüfen, ob links noch Bilder sind.
	 *  - Variable Counter runterzählen.
	 *  - Vorheriges Element holen.
	 *  - Aktuelles Element ausblenden.
	 *  - Vorheriges Element einblenden.
	 *  - Ausgeblendetes Element `.current` Klasse entfernen.
	 *  - Eingeblendetes Element `.current` Klasse geben.
	 *  - Variable für aktuelles Element ersetzen.
	 */


	/**
	 * Klick auf rechten Pfeil.
	 *  - Prüfen, ob rechts noch Bilder sind.
	 *  - Variable Counter hochzählen.
	 *  - Nächstes Element holen.
	 *  - Aktuelles Element ausblenden.
	 *  - Nächstes Element einblenden.
	 *  - Ausgeblendetes Element `.current` Klasse entfernen.
	 *  - Eingeblendetes Element `.current` Klasse geben.
	 *  - Variable für aktuelles Element ersetzen.
	 */


} );
